package ca.sheridancollege.fernkevi.ex21_requestMapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex21RequestMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex21RequestMappingApplication.class, args);
	}

}
