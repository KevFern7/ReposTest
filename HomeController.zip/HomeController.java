package ca.sheridancollege.<fernkevi>.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index() {
        return "index";  
    }

    @PostMapping("/formPost")
    public String handleFormPost(
            @RequestParam("firstName") String firstName,
            @RequestParam("email") String email,
            @RequestParam("appointmentDate") String appointmentDate,
            @RequestParam("appointmentTime") String appointmentTime) {
        
        
        LocalDate date = LocalDate.parse(appointmentDate);
        LocalTime time = LocalTime.parse(appointmentTime);

       
        Appointment appointment = new Appointment();
        appointment.setFirstName(firstName);
        appointment.setEmail(email);
        appointment.setAppointmentDate(date);
        appointment.setAppointmentTime(time);

        
        System.out.println(appointment);

        return "working"; 
    }
}
